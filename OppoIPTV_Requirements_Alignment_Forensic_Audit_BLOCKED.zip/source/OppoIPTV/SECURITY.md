# Security Policy

Do not report credentials, signing keys or private provider data in issues.

Security-sensitive changes require threat-model review, tests and explicit evidence.

Never use production secrets in automated tests.
