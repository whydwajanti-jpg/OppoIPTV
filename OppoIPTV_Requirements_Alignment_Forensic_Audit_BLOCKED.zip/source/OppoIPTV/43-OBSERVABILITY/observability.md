# Observability

## Events

Use structured events for:

- app startup;
- screen transitions;
- provider connection;
- catalog refresh;
- playback start;
- playback failure;
- network failure;
- recovery;
- crash.

## Privacy

Telemetry must be minimized and redacted. Never emit provider passwords, access tokens or complete authenticated URLs.

## Diagnostics

Debug mode may increase local diagnostics but must not weaken production security controls.
