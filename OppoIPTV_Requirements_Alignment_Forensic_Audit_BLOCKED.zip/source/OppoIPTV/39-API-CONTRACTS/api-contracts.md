# API Contracts

## Integration model

External provider APIs are accessed through adapters.

The application never assumes that an external API is correct.

## Required adapter behaviors

- timeout;
- cancellation;
- response validation;
- error classification;
- retry policy;
- pagination where needed;
- rate-limit handling;
- schema normalization.

## Credentials

Credentials are passed through secure configuration abstractions and are never included in diagnostic logs.

## Compatibility

Each adapter documents the provider/API variant it supports. Unsupported responses fail explicitly instead of being silently coerced into incorrect domain objects.
