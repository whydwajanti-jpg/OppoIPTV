# Data Contracts

Data contracts define normalized application data.

## Principles

- provider payloads are untrusted;
- external schemas are adapted;
- optional fields are explicit;
- dates use a canonical internal representation;
- URLs are validated;
- image URLs are treated as untrusted external resources;
- schema changes require compatibility analysis.

## Contract families

- provider connection;
- channel;
- EPG programme;
- VOD;
- series;
- season;
- episode;
- user profile;
- settings;
- playback state.

## Versioning

Provider adapters may support multiple upstream formats, but the domain contract remains stable unless an approved domain change occurs.
