# Samsung Tizen Platform Strategy

## Baseline

The project uses Samsung TV 2024 / Tizen 8 as the minimum modern-platform baseline, while retaining capability detection for later platform generations.

Samsung documents the TV Web application model as HTML/CSS/JavaScript plus `config.xml`, and provides Samsung/Tizen APIs for supported device capabilities.

## Platform principles

1. Prefer web standards when sufficient.
2. Isolate Samsung-specific APIs behind adapters.
3. Detect capabilities at runtime.
4. Keep remote navigation deterministic.
5. Test on real hardware for release-critical behavior.
6. Keep package configuration explicit.
7. Treat signing as a release security boundary.

## Resolution

Samsung documents a 16:9 application presentation model and identifies 1920x1080 as the standard application resolution for UHD TV application groups. UI assets and layouts should therefore be authored against a 1920x1080 design grid while remaining responsive to supported TV groups.

## Lifecycle

The app must explicitly handle:

- startup;
- visibility changes;
- suspend/resume;
- network changes;
- player teardown;
- exit/back behavior;
- storage failures.

## Package

`config.xml` is mandatory for a Tizen Web application. Application IDs, privileges, features and package metadata must be reviewed before packaging.

## Device compatibility

Do not infer support solely from model year. Maintain a capability matrix and verify APIs and media formats against Samsung's current platform specifications.
