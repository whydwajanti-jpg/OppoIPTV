# Reliability Strategy

## Failure domains

- network;
- provider;
- parser;
- storage;
- platform;
- media;
- UI state;
- application lifecycle.

## Principles

Every external operation has a bounded timeout and an explicit failure state.

## Recovery

Where safe:

1. cancel stale work;
2. retry with bounded backoff;
3. refresh provider metadata;
4. recreate player resources;
5. restore user-visible state;
6. offer manual recovery.

## No infinite loops

Retry loops have a maximum count, maximum elapsed time and escalation path.
