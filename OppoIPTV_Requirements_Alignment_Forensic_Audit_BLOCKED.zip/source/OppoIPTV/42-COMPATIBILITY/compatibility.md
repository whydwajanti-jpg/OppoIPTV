# Compatibility Strategy

Samsung's public platform specifications show that TV capabilities vary by model year and can change with OS upgrades.

Therefore compatibility is expressed as:

`Device + Tizen + Capability + Feature`

rather than only:

`Device year`.

## Matrix dimensions

- OS version;
- browser/web engine;
- video codecs;
- audio codecs;
- stream protocols;
- DRM availability;
- storage;
- network behavior;
- remote APIs.

## Release rule

A feature marked supported must have evidence from the supported device matrix or a documented reason why emulator/browser verification is sufficient.
