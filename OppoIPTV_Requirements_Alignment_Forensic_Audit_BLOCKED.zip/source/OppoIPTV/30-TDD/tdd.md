# Test-Driven Development

TDD governs implementation order.

## Cycle

`Red -> Green -> Refactor`

## Rules

- write a focused failing test for new behavior;
- implement the smallest correct change;
- refactor without changing behavior;
- keep tests deterministic;
- avoid tests that depend on real provider infrastructure.

## Test priority

Domain invariants and parsers are highly suitable for TDD. Samsung APIs are covered through adapter tests and device verification.
