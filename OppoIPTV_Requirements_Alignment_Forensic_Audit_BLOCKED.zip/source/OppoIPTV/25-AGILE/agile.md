# Agile Operating Model

Agile governs product change.

## Rules

- maintain a prioritized backlog;
- slice work vertically;
- validate outcomes early;
- treat feedback as a first-class input;
- avoid building large unvalidated batches.

## Change

A change enters the product backlog, receives impact analysis, and becomes an OpenSpec change before implementation.

## Done

Done means verified product value, not merely code merged.
