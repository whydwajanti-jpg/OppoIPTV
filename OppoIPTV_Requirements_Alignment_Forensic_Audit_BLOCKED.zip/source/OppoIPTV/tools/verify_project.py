#!/usr/bin/env python3
"""Deterministic repository forensic verifier for OppoIPTV."""
from __future__ import annotations
import json, re, sys
from pathlib import Path
from xml.etree import ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []
warnings: list[str] = []

def require(path: str) -> Path:
    p = ROOT / path
    if not p.exists(): errors.append(f"missing: {path}")
    return p

for path in ["README.md","BUILD_PLAN.md","MASTER_FILE_MANIFEST.md","config.xml","package.json","project.yaml","AUTONOMOUS_AI_COMMAND/command.yaml","AUTONOMOUS_AI_COMMAND/lifecycle.yaml","40-UI-UX-SYSTEM/visual-overhaul-v1.md","src/ui/App.tsx","src/ui/styles/tv.css","public/icons/app-icon.png"]:
    require(path)

try:
    pkg=json.loads((ROOT/'package.json').read_text())
    expected={
      'react':'^19.2.7','react-dom':'^19.2.7',
    }
    for k,v in expected.items():
        if pkg['dependencies'].get(k)!=v: errors.append(f"package dependency drift: {k}")
    for k,v in {'vite':'^8.2.2','typescript':'^7.0.2','vitest':'^4.1.11','eslint':'^10.9.1','prettier':'^3.9.6','@vitejs/plugin-react':'^6.1.1'}.items():
        if pkg['devDependencies'].get(k)!=v: errors.append(f"package devDependency drift: {k}")
except Exception as exc: errors.append(f"invalid package.json: {exc}")

try:
    root=ET.parse(ROOT/'config.xml').getroot()
    icon=root.find('{http://www.w3.org/ns/widgets}icon')
    if icon is None or icon.attrib.get('src')!='icons/app-icon.png': errors.append('config.xml icon path mismatch')
    if root.find('{http://tizen.org/ns/widgets}profile') is None: errors.append('config.xml missing Samsung TV profile')
except Exception as exc: errors.append(f"invalid config.xml: {exc}")

# Broken local references in markdown are a common failure mode in generated plans.
md=list(ROOT.rglob('*.md'))
for p in md:
    text=p.read_text(encoding='utf-8',errors='replace')
    for ref in re.findall(r'\]\(([^)]+)\)', text):
        if ref.startswith(('http://','https://','#','mailto:')): continue
        target=(p.parent/ref).resolve()
        if not target.exists(): errors.append(f"broken markdown ref: {p.relative_to(ROOT)} -> {ref}")

# No production source may contain accidental mock/test endpoint markers.
for p in (ROOT/'src').rglob('*'):
    if p.is_file() and p.suffix in {'.ts','.tsx','.css','.html'}:
        text=p.read_text(encoding='utf-8',errors='replace').lower()
        for marker in ['example.test','todo','fixme','not implemented','mock provider']:
            if marker in text: errors.append(f"production marker '{marker}' in {p.relative_to(ROOT)}")

# Check the project has a real test inventory and the visual artifact.
if len(list((ROOT/'tests').rglob('*test.ts*'))) < 1: errors.append('no automated tests found')
if len(list((ROOT/'src/ui').rglob('*.tsx'))) < 4: warnings.append('UI component surface is unexpectedly small')

# UI reference integrity: class names and icon names used by TSX must exist in the visual contract.
css=(ROOT/'src/ui/styles/tv.css').read_text(encoding='utf-8')
for p in (ROOT/'src/ui').rglob('*.tsx'):
    text=p.read_text(encoding='utf-8',errors='replace')
    for cls in re.findall(r'className=\"([^\"]+)\"', text):
        for name in cls.split():
            if name and name not in css: warnings.append(f'UI class not found in CSS: {name} ({p.relative_to(ROOT)})')
    for icon in re.findall(r'<Icon name=\"([^\"]+)\"', text):
        if icon not in {"home","live","movie","series","guide","heart","settings","search","plus","arrow","play","chevron","wifi","shield"}:
            errors.append(f'unknown UI icon: {icon}')

print(f"FORENSIC_CHECK files={sum(1 for _ in ROOT.rglob('*') if _.is_file())} markdown={len(md)}")
if warnings:
    print('WARNINGS:')
    for w in warnings: print(f"- {w}")
if errors:
    print('ERRORS:')
    for e in errors: print(f"- {e}")
    sys.exit(1)
print('PASS: repository structure, package baseline, Tizen metadata, local references, production-marker scan, and UI artifact checks.')
