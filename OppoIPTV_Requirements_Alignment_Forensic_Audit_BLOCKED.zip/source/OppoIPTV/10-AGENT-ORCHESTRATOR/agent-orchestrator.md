# Agent Orchestrator

The orchestrator converts a task graph into bounded worker executions.

## Worker roles

- planner
- researcher
- product
- specification
- domain
- architect
- UI
- Samsung
- media
- coder
- tester
- security
- performance
- reviewer
- debugger
- verifier
- release

## Routing

A task is routed by capability and risk, not by arbitrary agent preference.

Examples:

- Tizen API issue -> Samsung worker.
- Playback failure -> media + Samsung worker.
- Authentication behavior -> domain + security worker.
- UI focus bug -> UI worker + browser verification.
- Release package failure -> release worker.

## Isolation

Workers receive explicit read/write permissions. A worker may not modify unrelated directories merely because it can.

## Handoff contract

Every handoff contains:

- task ID;
- current state;
- completed work;
- files changed;
- tests;
- evidence;
- blockers;
- next recommended worker.

## Escalation

Escalate when:

- requirements conflict;
- credentials or secrets are needed;
- destructive action is requested;
- platform behavior is uncertain and cannot be verified;
- repeated repair attempts fail;
- release signing is required without authorized credentials.
