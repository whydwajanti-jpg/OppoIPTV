# Autonomous Readiness

Autonomy is earned through verification, not enabled by default.

## Levels

0. Manual.
1. AI-assisted planning.
2. AI-assisted implementation with mandatory review.
3. Bounded autonomous task execution with tests.
4. Autonomous multi-step execution with repair loops and evidence.
5. High-autonomy release preparation under strict gates.

## Gates

An autonomous worker may progress only when:

- task scope is explicit;
- allowed paths are known;
- required tools are available;
- acceptance criteria are executable;
- risk is within policy;
- secrets are unavailable unless explicitly authorized;
- verification commands are defined.

## Stop conditions

Stop and escalate for:

- ambiguous requirements;
- security-sensitive behavior;
- destructive filesystem operations;
- signing credentials;
- repeated failed repair;
- contradictory specifications;
- unexplained platform behavior.
