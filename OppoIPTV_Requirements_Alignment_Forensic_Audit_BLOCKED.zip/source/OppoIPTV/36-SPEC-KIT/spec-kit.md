# Spec Kit Integration

Spec Kit is used as the AI-oriented specification workflow.

## Core flow

`Specify -> Plan -> Tasks -> Implement`

Spec Kit's current documentation describes this as the core Spec-Driven Development sequence.

## OppoIPTV extension

The project adds:

- Samsung capability verification;
- DDD domain checks;
- BDD scenarios;
- TDD gates;
- evidence generation;
- PEOS policy;
- autonomous worker routing.

## Rule

Spec Kit artifacts are inputs to engineering execution, not a replacement for testing or Samsung device verification.
