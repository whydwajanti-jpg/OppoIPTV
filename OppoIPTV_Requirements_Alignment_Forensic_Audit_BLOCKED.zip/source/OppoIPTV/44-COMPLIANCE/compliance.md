# Compliance and Legal Boundaries

## Content

OppoIPTV is a client application. Users must provide lawful access to IPTV services and media.

## Third-party software

Maintain an inventory of open-source dependencies and licenses.

## Privacy

Document what local data is stored, why it is needed, retention behavior and deletion/reset behavior.

## Store readiness

Before distribution, validate Samsung store requirements applicable to the chosen distribution path, package metadata, signing, permissions, privacy declarations and content policies.
