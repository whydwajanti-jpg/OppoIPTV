# Third Party Notices

## Purpose

This artifact belongs to `44-COMPLIANCE` and defines the engineering contract for **Third Party Notices** in OppoIPTV.

It is a durable project artifact, not a disposable note. Any AI worker touching related implementation must read the relevant governing specification and this artifact before changing code.

## Scope

- Define the purpose and scope of this artifact.
- Identify inputs, outputs, dependencies and owners.
- State invariants and failure behavior.
- Define verification and evidence requirements.

## Required sections

### Inputs

List upstream requirements, specifications, platform facts, configuration and dependencies.

### Outputs

Describe the observable result, generated artifacts, code changes or evidence produced.

### Invariants

- No silent behavior changes.
- No credentials or secrets in source control.
- External input is treated as untrusted.
- Failure behavior is explicit.
- Changes are traceable to a task and requirement.

### Failure behavior

Every operation covered by this artifact must define what happens when:

1. input is invalid;
2. a dependency is unavailable;
3. the platform lacks a capability;
4. a timeout occurs;
5. a retry budget is exhausted.

### Verification

Verification must be executable where possible. The worker must record commands, environment and results.

### Dependencies

Reference the upstream requirements, architecture decisions, domain contracts and test artifacts that constrain this artifact.

### Change policy

Material changes require an OpenSpec change or equivalent approved change record. AI workers must not silently rewrite the source of truth to accommodate an implementation.

## Completion criteria

- scope is explicit;
- acceptance behavior is testable;
- failure behavior is defined;
- dependencies are traceable;
- implementation and tests can reference this artifact;
- evidence can prove completion.
