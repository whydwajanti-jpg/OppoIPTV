# Contributing

All changes follow the specification-first workflow.

1. Define or update the requirement.
2. Create/modify an OpenSpec change.
3. Clarify ambiguity.
4. Plan and create tasks.
5. Implement with TDD.
6. Verify BDD/E2E/device behavior as appropriate.
7. Record evidence.
8. Submit the change for review.
