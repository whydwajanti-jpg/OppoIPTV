# Build Plan

## Baseline package

Generated: 2026-09-01

This archive is a **production engineering blueprint + executable bootstrap**, not a finished IPTV product. It deliberately avoids pretending that a collection of markdown files or a UI shell is already a completed application.

## Execution order

1. Validate technology and Samsung baseline.
2. Freeze architecture and requirements.
3. Implement foundation vertical slice.
4. Implement provider connection.
5. Implement catalog normalization.
6. Implement Live TV.
7. Implement media/player subsystem.
8. Implement EPG.
9. Implement VOD.
10. Implement series.
11. Implement search/library/settings.
12. Harden security/reliability/performance.
13. Run browser + emulator + real-device verification.
14. Package/sign/release.

## Exit condition

The project is complete only when all release gates in `20-RELEASE`, `31-CI-CD`, `14-VERIFICATION`, `15-EVIDENCE`, `17-SAMSUNG-TIZEN` and `42-COMPATIBILITY` are satisfied.

## Why the package is structured this way

Samsung documents Tizen TV Web applications, required `config.xml`, signing requirements, remote-first interaction and a platform matrix whose capabilities vary across device generations. The repository therefore treats platform verification as an engineering activity rather than a documentation assumption.

Spec Kit is used for intent-driven Spec -> Plan -> Tasks -> Implement flow, while OpenSpec provides explicit change/spec/source-of-truth separation. PEOS coordinates both with testing and evidence.
