# GitHub Actions Verification Pipeline

`.github/workflows/ci.yml` is the repository-level implementation of the pull-request gate.

## Required gates

1. install dependencies;
2. run forensic/static verification;
3. TypeScript typecheck;
4. ESLint;
5. Vitest unit tests;
6. production Vite build.

Tizen package signing and hardware smoke tests remain protected release stages and are not performed on ordinary pull requests.
