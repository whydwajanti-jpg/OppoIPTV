# CI/CD

## Pull request pipeline

1. install dependencies from lockfile;
2. lint;
3. typecheck;
4. unit tests;
5. integration tests;
6. architecture checks;
7. dependency/security checks;
8. build;
9. package validation.

## Release pipeline

Adds:

- release candidate;
- Tizen package;
- signing in protected environment;
- artifact integrity;
- device smoke test;
- evidence bundle.

## Principle

A green build is necessary but not sufficient for release.
