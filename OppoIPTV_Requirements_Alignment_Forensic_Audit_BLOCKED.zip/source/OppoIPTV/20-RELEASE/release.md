# Release Engineering

## Release stages

1. Development.
2. CI validation.
3. Release candidate.
4. Packaging.
5. Signing.
6. Device smoke test.
7. Critical-flow verification.
8. Evidence review.
9. Release approval.
10. Publication/deployment.

## Versioning

Use semantic versioning for application behavior where practical. Samsung package/version constraints are validated separately.

## Signing

Signing credentials are managed outside the repository. A release worker may invoke signing only when an authorized environment exposes the required credentials.

## Rollback

Every release must identify the last known-good release and retain enough evidence to reproduce the decision.
