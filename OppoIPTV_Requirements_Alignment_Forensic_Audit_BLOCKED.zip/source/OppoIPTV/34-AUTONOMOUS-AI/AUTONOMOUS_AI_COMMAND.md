# AUTONOMOUS_AI_COMMAND

This document defines the portable command contract for a runnable AI worker engine.

## Command input

```yaml
command_id: string
task_id: string
objective: string
workspace: string
allowed_read_paths: []
allowed_write_paths: []
required_checks: []
constraints: []
timeout_seconds: integer
max_retries: integer
escalation_policy: string
```

## Command lifecycle

```text
ACCEPT
  -> LOAD_CONTEXT
  -> PLAN
  -> EXECUTE
  -> TEST
  -> VERIFY
  -> EMIT_EVIDENCE
  -> COMPLETE
```

Failure path:

```text
EXECUTE -> FAILURE -> CLASSIFY -> REPAIR -> TEST -> VERIFY
                               \-> ESCALATE
```

## Universal AI Worker Adapter

The adapter abstracts the model/provider from the project execution protocol.

The worker engine must not assume one vendor, model, CLI or chat interface.

### Required adapter operations

- `discover_capabilities`
- `start_session`
- `send_context`
- `request_plan`
- `request_action`
- `request_review`
- `close_session`

### Worker response contract

```yaml
status: completed|failed|blocked|escalated
summary: string
changed_files: []
commands_run: []
tests_run: []
evidence: []
warnings: []
next_action: string|null
```

## Security

Workers have no implicit secret access. The adapter must enforce path and command policy before execution.

## Convergence

A task is converged only when acceptance checks pass and no required evidence is missing.

## Human escalation

Escalate instead of guessing when the specification is ambiguous or the platform behavior is unknown.
