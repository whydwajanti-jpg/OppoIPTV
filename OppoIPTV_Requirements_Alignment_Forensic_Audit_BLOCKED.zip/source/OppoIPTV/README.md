# OppoIPTV

## Purpose

OppoIPTV is a production-oriented IPTV application blueprint and implementation workspace for modern Samsung Smart TVs. The project is designed to produce a real installable, testable, maintainable TV application rather than a visual prototype.

The repository separates:

1. product intent;
2. requirements and acceptance criteria;
3. domain modeling;
4. architecture;
5. implementation specifications;
6. AI execution policy;
7. source code;
8. tests;
9. Samsung/Tizen verification;
10. evidence and release management.

The project is explicitly **capability-driven**. It does not assume that every TV model exposes identical APIs or media capabilities.

## Important scope boundary

The application may implement IPTV client functionality such as playlist import, provider/API integration, EPG, live playback, VOD, series, search, favorites, history, parental controls, subtitles and settings.

It does **not** bundle or distribute unauthorized television content. The application is a client and must be used with content and provider credentials that the user is legally entitled to use.

## Samsung baseline

Samsung's current developer documentation identifies 2024 TV models with Tizen 8.0 as the baseline platform generation. Samsung also notes that post-2023 devices can receive OS upgrades, so the implementation must use runtime capability detection rather than hard-coding a single firmware assumption.

The TV web application must respect the remote-first interaction model, 16:9 presentation, TV-safe navigation, package signing and Samsung/Tizen application rules.

## Engineering rule

No production feature is considered complete merely because its UI renders.

A feature is complete only when:

- its requirement is defined;
- its behavior is specified;
- its domain implications are modeled;
- its implementation is covered by tests;
- its integration behavior is verified;
- its target-TV behavior is checked where applicable;
- evidence is recorded;
- regressions are addressed;
- the release gate accepts it.

## Development sequence

`Product -> Requirements -> Specify -> Clarify -> Domain -> Architecture -> BDD -> Tasks -> TDD -> Implement -> Verify -> Evidence -> Release`

## AI execution sequence

`Request -> Change proposal -> Specification -> Clarification -> Plan -> Task graph -> Context compilation -> Worker execution -> Tests -> Repair loop -> Verification -> Evidence -> Merge`

## Repository map

- `01-PRODUCT` through `45-DOCUMENTATION`: durable engineering knowledge and governance.
- `openspec`: change-oriented specifications and source-of-truth artifacts.
- `.specify`: Spec Kit integration area.
- `agents`: AI roles, contracts and workflows.
- `AUTONOMOUS_AI_COMMAND`: executable worker contract and runtime state model.
- `src`: production application.
- `tests`: automated quality system.
- `scripts`: build, verification, Tizen and AI automation.
- `tools`: reusable engineering engines.
- `.github`: CI/CD.
- `configs`: environment/platform configuration.
- `artifacts`: generated evidence and build outputs.
- `runtime`: local execution state only; never commit secrets.

## Definition of production-ready

Production-ready means the application can be built from a clean checkout, packaged according to Samsung/Tizen rules, installed on supported test devices, configured with lawful provider data, and exercised through the critical user journeys without known release-blocking defects.

## Sources

- Samsung TV Web application development and packaging guidance.
- Samsung TV platform specification matrix.
- GitHub Spec Kit's current Spec-Driven Development workflow.
- OpenSpec's current change/specification workflow.

See `04-KNOWLEDGE/sources.md` and `35-OPEN-SPEC/openspec.md`.
