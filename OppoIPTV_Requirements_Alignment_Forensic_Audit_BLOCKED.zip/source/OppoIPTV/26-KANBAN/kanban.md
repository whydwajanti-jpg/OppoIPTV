# Kanban Flow

Kanban governs work-in-progress.

## Board

`Backlog -> Ready -> Specifying -> Planned -> Implementing -> Verifying -> Review -> Done`

Additional states:

`Blocked`, `Escalated`, `Repairing`.

## WIP

WIP limits prevent the AI system from generating more unfinished work than the verification system can absorb.

## Pull

Workers pull the highest-priority task whose prerequisites are satisfied.

## Metrics

Track cycle time, blocked time, throughput, rework rate and verification failure rate.
