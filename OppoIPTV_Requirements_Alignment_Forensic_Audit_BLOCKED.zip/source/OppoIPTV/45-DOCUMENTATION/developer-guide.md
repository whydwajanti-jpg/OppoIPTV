# Developer Guide

## First setup

1. Install Node.js version defined by `.nvmrc`.
2. Install dependencies from the lockfile.
3. Install Samsung/Tizen development tools required for packaging and device verification.
4. Configure a development certificate/profile when device installation requires it.
5. Run static checks.
6. Run unit tests.
7. Start the browser development environment.
8. Run Samsung device smoke tests when available.

## Feature development

For every new feature:

1. create/update OpenSpec change;
2. clarify ambiguity;
3. update requirement/spec;
4. model domain behavior;
5. write BDD scenarios;
6. create task graph;
7. write TDD tests;
8. implement;
9. run integration tests;
10. verify on target platform where needed;
11. record evidence;
12. update documentation.

## Do not

- hard-code provider credentials;
- bypass tests;
- assume browser behavior equals Samsung behavior;
- place Samsung APIs in domain entities;
- add unbounded retry loops;
- silently swallow playback errors.
