# Scrum Delivery Model

Scrum governs time-boxed delivery when a team chooses sprint execution.

## Sprint

Each sprint has:

- sprint goal;
- selected tasks;
- acceptance criteria;
- verification target;
- review;
- retrospective.

AI workers can execute tasks inside the sprint but do not redefine the sprint goal without a product-level change.
