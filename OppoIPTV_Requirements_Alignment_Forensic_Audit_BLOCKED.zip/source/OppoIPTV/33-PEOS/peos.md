# PEOS — Project Engineering Operating System

PEOS is the control plane that coordinates the other engineering methods.

## Responsibilities

- enforce constitution;
- route changes;
- maintain task graph;
- compile context;
- authorize worker capabilities;
- enforce verification gates;
- collect evidence;
- trigger bounded repairs;
- escalate when autonomy is unsafe.

## Gate sequence

`Intent -> Spec -> Plan -> Tasks -> Implement -> Test -> Verify -> Evidence -> Release`

## Authority

PEOS cannot override the constitution or approved specifications. It orchestrates; it does not invent product truth.
