# Performance Engineering

## Budgets

The exact thresholds are finalized after measurement on representative Samsung devices. The project must not invent device-independent numbers.

Initial measurable objectives:

- startup: minimize blocking work before first interactive screen;
- navigation: avoid unnecessary full-screen re-renders;
- catalog: parse incrementally where data is large;
- EPG: virtualize large timelines;
- playback: minimize time from channel selection to media start;
- memory: release player resources when leaving playback.

## Techniques

- lazy-load noncritical screens;
- memoize expensive derived catalog data;
- avoid rendering thousands of nodes;
- use indexed local storage structures;
- cancel obsolete requests;
- release media resources deterministically;
- instrument startup and channel-switch timing.

## Measurement

Performance claims require evidence from the same build and a documented test environment.
