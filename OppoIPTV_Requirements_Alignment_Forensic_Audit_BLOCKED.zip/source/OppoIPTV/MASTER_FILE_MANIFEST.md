# Master File Manifest

This file defines the role of every durable artifact in the repository.

## Artifact classes

| Class | Meaning | May generate code? | Source of truth? |
|---|---|---:|---:|
| Product | Product intent and scope | Indirectly | Yes for product intent |
| Requirement | Testable system need | Yes | Yes |
| Specification | Behavioral/technical contract | Yes | Yes |
| Architecture | Structural decisions | Yes | Yes for structure |
| Domain | Business model | Yes | Yes for domain semantics |
| BDD | User-visible behavior | Yes | Yes for expected behavior |
| TDD | Implementation verification | No | Yes for executable checks |
| Governance | Rules and authority | Constrains all work | Yes |
| AI | Worker behavior | Controls AI | Yes |
| Evidence | Proof of work | No | Yes for verification status |
| Source | Actual application | Implements | No; must conform |
| Tests | Executable verification | No | Verification authority |
| Scripts | Automation | Operational | No |
| Runtime | Temporary execution state | No | No |

## File lifecycle

Every significant artifact has:

- owner;
- purpose;
- inputs;
- outputs;
- dependencies;
- validation method;
- update trigger;
- version history.

## AI rule

An AI worker must never modify a specification merely to make a failing implementation pass. If implementation contradicts an approved requirement, the worker must either repair the implementation or create an explicit change proposal.

## Change propagation

Requirement change -> impact analysis -> OpenSpec change -> updated spec -> affected task graph -> implementation -> tests -> evidence -> archive.

## Completeness rule

An empty directory is not an implementation. A document containing only headings is not a specification. A task saying "implement feature" without acceptance criteria is not executable work.
