# SOURCE REQUIREMENTS GATE

## Gate: BLOCKED

Required external source:

`iptv smarters pro-Requirements`

Current state:

`NOT PROVIDED / NOT FOUND`

This file is intentionally a hard gate. AI workers MUST NOT fabricate or infer the missing source requirements.

### Unlock condition

A complete authoritative copy of `iptv smarters pro-Requirements` must be supplied.

### Required processing after unlock

1. Ingest the complete source.
2. Assign stable requirement IDs if the source lacks them, while preserving original identifiers/text.
3. Extract mandatory/optional requirements and acceptance criteria.
4. Compare against every applicable OppoIPTV requirement.
5. Classify each mapping as VERIFIED / DERIVED / MISSING / CONFLICT / UNKNOWN.
6. Reconcile conflicts while preserving OppoIPTV identity.
7. Rewrite affected engineering artifacts.
8. Rebuild requirement → capability → specification → task → verification traceability.
9. Re-audit all changed files.
10. Verify cross-file references and release gates.
11. Produce a final evidence-backed completion report.

No final alignment PASS may be emitted before this gate is satisfied.
